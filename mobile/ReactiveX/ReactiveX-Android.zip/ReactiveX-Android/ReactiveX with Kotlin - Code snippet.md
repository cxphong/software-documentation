# ReactiveX with Kotlin - Code snippet

See more at http://reactivex.io/documentation/operators.html

### 1. Creating Observables

##### Create a custom observable

```kotlin
val observer = object : Observer<Long> {
    override fun onSubscribe(d: Disposable) {
        Log.d(TAG, "onSubscribe() called with: $d")
    }

    override fun onNext(t: Long) {
        Log.d(TAG, "onNext() called with: $t")
    }

    override fun onError(t: Throwable) {
        Log.d(TAG, "onError() called with: $t")
    }

    override fun onComplete() {
        Log.d(TAG, "onComplete() called")
    }
}

val observable = object : Observable<Long>() {
    override fun subscribeActual(observer: Observer<in Long>) {
        for (i in 0L..5L) {
            observer.onNext(i)
        }
        observer.onComplete()
        observer.onError(Throwable("Unknown error"))
    }

}

observable.subscribe(observer)
```

##### Interval observable

```kotlin
Observable.interval(1, TimeUnit.SECONDS)
    .subscribe(object:Observer<Long>{
        override fun onSubscribe(d: Disposable) {
            Log.d(TAG, "onSubscribe() called")
        }

        override fun onNext(t: Long) {
            Log.d(TAG, "onNext: $t")
        }

        override fun onError(e: Throwable) {
            Log.d(TAG, "onError: ${e}")
        }

        override fun onComplete() {
            Log.d(TAG, "onComplete() called")
        }

    })
```

##### From

```kotlin
val observer = object : Observer<Long> {
    override fun onSubscribe(d: Disposable) {
        Log.d(TAG, "onSubscribe() called with: $d")
    }

    override fun onNext(t: Long) {
        Log.d(TAG, "onNext() called with: $t")
    }

    override fun onError(t: Throwable) {
        Log.d(TAG, "onError() called with: $t")
    }

    override fun onComplete() {
        Log.d(TAG, "onComplete() called")
    }
}

arrayOf(1L, 2L, 3L).toObservable().subscribe(observer)
```



### 2. Transforming Observables

##### Buffer

```kotlin
Observable.interval(1, TimeUnit.SECONDS)
    .buffer(5)
    .subscribe(object:Observer<List<Long>>{
        override fun onSubscribe(d: Disposable) {
            Log.d(TAG, "onSubscribe() called")
        }

        override fun onNext(t: List<Long>) {
            Log.d(TAG, "onNext: $t")
        }

        override fun onError(e: Throwable) {
            Log.d(TAG, "onError: ${e}")
        }

        override fun onComplete() {
            Log.d(TAG, "onComplete() called")
        }

    })
```

##### FlatMap

```kotlin
Observable.interval(1, TimeUnit.SECONDS)
    .flatMap {
        arrayOf(it * 2, it * 3).toObservable()
    }.subscribe(object : Observer<Long> {
        override fun onSubscribe(d: Disposable) {
            Log.d(TAG, "onSubscribe() called")
        }

        override fun onNext(t: Long) {
            Log.d(TAG, "onNext: $t")
        }

        override fun onError(e: Throwable) {
            Log.d(TAG, "onError: ${e}")
        }

        override fun onComplete() {
            Log.d(TAG, "onComplete() called")
        }

    })
```

##### Map

```kotlin
Observable.interval(500, TimeUnit.MILLISECONDS)
    .map { it*2 }.subscribe(object : Observer<Long> {
        override fun onSubscribe(d: Disposable) {
            Log.d(TAG, "Odd: onSubscribe() called")
        }

        override fun onNext(t: Long) {
            Log.d(TAG, "Odd: onNext: $t")
        }

        override fun onError(e: Throwable) {
            Log.d(TAG, "Odd: onError: ${e}")
        }

        override fun onComplete() {
            Log.d(TAG, "Odd: onComplete() called")
        }

    })
```

##### Scan

```kotlin
Observable.interval(1, TimeUnit.SECONDS)
    .scan { a: Long, b: Long -> a + b }.subscribe(object : Observer<Long> {
        override fun onSubscribe(d: Disposable) {
            Log.d(TAG, "onSubscribe() called")
        }

        override fun onNext(t: Long) {
            Log.d(TAG, "onNext: $t")
        }

        override fun onError(e: Throwable) {
            Log.d(TAG, "onError: $e")
        }

        override fun onComplete() {
            Log.d(TAG, "onComplete() called")
        }

    })
```

##### GroupBy

```kotlin
val obs_odd = object : Observer<Long> {
    override fun onSubscribe(d: Disposable) {
        Log.d(TAG, "Odd: onSubscribe() called")
    }

    override fun onNext(t: Long) {
        Log.d(TAG, "Odd: onNext: $t")
    }

    override fun onError(e: Throwable) {
        Log.d(TAG, "Odd: onError: ${e}")
    }

    override fun onComplete() {
        Log.d(TAG, "Odd: onComplete() called")
    }

}

val obs_even = object : Observer<Long> {
    override fun onSubscribe(d: Disposable) {
        Log.d(TAG, "Even: onSubscribe() called")
    }

    override fun onNext(t: Long) {
        Log.d(TAG, "Even: onNext: $t")
    }

    override fun onError(e: Throwable) {
        Log.d(TAG, "Even: onError: ${e}")
    }

    override fun onComplete() {
        Log.d(TAG, "Even: onComplete() called")
    }

}

Observable.interval(500, TimeUnit.MILLISECONDS)
    .groupBy { it % 2 == 0L }
    .subscribe(object : Observer<GroupedObservable<Boolean, Long>>{
        override fun onSubscribe(d: Disposable) {
            Log.d(TAG, "onSubscribe() called")
        }

        override fun onNext(t: GroupedObservable<Boolean, Long>) {
            if (t.key!!) {
                t.subscribe(obs_even)
            } else {
                t.subscribe(obs_odd)
            }
        }

        override fun onError(e: Throwable) {
            Log.d(TAG, "onError: ${e}")
        }

        override fun onComplete() {
            Log.d(TAG, "onComplete() called")
        }

    })
```

##### Window

```kotlin
Observable.interval(1, TimeUnit.SECONDS)
    .window(5)
    .subscribe(object : Observer<Observable<Long>> {
        override fun onSubscribe(d: Disposable) {
            Log.d(TAG, "onSubscribe() called")
        }

        override fun onNext(t: Observable<Long>) {
            t.subscribe(object : Observer<Long> {
                override fun onSubscribe(d: Disposable) {
                    Log.d(TAG, "onSubscribe() called on $this")
                }

                override fun onNext(t1: Long) {
                    Log.d(TAG, "onNext: $t1  on $this")
                }

                override fun onError(e: Throwable) {
                    Log.d(TAG, "onError: $e on $this")
                }

                override fun onComplete() {
                    Log.d(TAG, "onComplete() called on $this")
                }

            })
        }

        override fun onError(e: Throwable) {
            Log.d(TAG, "onError: $e")
        }

        override fun onComplete() {
            Log.d(TAG, "onComplete() called")
        }

    })
```